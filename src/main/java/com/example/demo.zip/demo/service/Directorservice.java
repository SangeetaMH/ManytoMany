package com.example.demo.service;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Director;
import com.example.demo.entity.Movies;
import com.example.demo.repository.Directorrepository;
import com.example.demo.repository.Moviesrepository;


@Service
public class Directorservice {
 @Autowired
 private Directorrepository repo;
 @Autowired
 private Moviesrepository mv;
public Director saveDirector(Director director)
	{
		return repo.save(director);
	}
//public Director updateDirector(Director director,int id)
//{
//	Director exsitingD = repo.findById(id);
//	exsitingD .setAge(director.getAge());
//	exsitingD .setAwardcount(director.getAwardcount());
//	return repo.save(exsitingD);
//   
//}
public  Set<Director> getDiector(String name) {
	
	return repo.findByName(name);
	
}
//public Set<Director> getDetails(String name){
//	return repo.findBymoviename(name);
//	
//}
}
